﻿// See https://aka.ms/new-console-template for more information
using SnakeAndLadderGame;

Console.WriteLine("Hello, World!");

//Game Start and display welcome message.
//Console.WriteLine("Welcome to Snake and Ladder Game!");
//Console.WriteLine("Press any key to start the game.");
//SnakeAndLadder game = new SnakeAndLadder();
//game.Start();
//Console.WriteLine(game.Start());
//Console.ReadKey();

////Roll the dice and get the dice number
////Random random = new Random();
//int diceNumber = game.DiceRoll();

//Console.WriteLine("You rolled a dice and got: " + diceNumber);