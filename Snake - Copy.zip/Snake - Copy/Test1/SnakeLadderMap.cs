﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakeAndLadderGame
{
    public class SnakeLadderMap
    { 
        //// Assuming the size is a 3x3 grid

        //// Define the map to represent snakes and ladders
        //private Dictionary<int, int> snakeMap;
        //private Dictionary<int, int> ladderMap;

        //public SnakeLadderMap()
        //{
        //    // Initialize the snake and ladder maps
        //    InitializeSnakeMap();
        //    InitializeLadderMap();
        //}

        private void InitializeMap()
        {
            
        }

        //private void InitializeLadderMap()
        //{
        //    // Define positions of ladders (startPosition, endPosition)
        //    ladderMap = new Dictionary<int, int>
        //    {
        //        { 3, 8 } // Ladder at position 3 leads to position 8
        //    };
        //}

        //public bool IsSnake(int position)
        //{
        //    return snakeMap.ContainsKey(position);
        //}

        //public bool IsLadder(int position)
        //{
        //    return ladderMap.ContainsKey(position);
        //}

        //public int GetSnakeEndPosition(int startPosition)
        //{
        //    return snakeMap[startPosition];
        //}
        //public int GetLadderEndPosition(int startPosition)
        //{
        //    return ladderMap[startPosition];
        //}
    }
}
