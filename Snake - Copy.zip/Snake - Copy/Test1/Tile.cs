﻿namespace SnakeAndLadderGame
{
    public class Tile
    {
        public Tile()
        {
        }

        public int PositionToTakeTo { get; set; }
        public TileType TileType { get; set; }
    }

}